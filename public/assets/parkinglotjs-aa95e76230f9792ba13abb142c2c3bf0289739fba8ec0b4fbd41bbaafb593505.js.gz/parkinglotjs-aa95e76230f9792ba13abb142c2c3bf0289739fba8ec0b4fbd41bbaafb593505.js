$("show-spot").on("click", function(){
	alert('Great'); 
	event.preventDefault(); 
});
